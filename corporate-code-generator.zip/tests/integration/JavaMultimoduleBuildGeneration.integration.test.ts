import { readFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { describe, expect, it } from "vitest";
import {
  GenerationPlanner,
  ModuleResolver,
  ModelLoader,
  ModelParser,
  ModelSchemaRegistry,
  ProfileResolver,
  SchemaValidator,
  SchemaVersionDetector,
  SemanticValidator,
  TemplatePackResolver,
} from "@corporate-code-generator/core";
import { JavaSpringCleanMultimoduleBuildArtifactProducer } from "@corporate-code-generator/adapter-java";
import { JavaSpringCleanMultimoduleConfigurationArtifactProducer } from "@corporate-code-generator/adapter-java";
import { JavaSpringCleanMultimoduleCoreArtifactProducer } from "@corporate-code-generator/adapter-java";
import { JavaSpringCleanMultimoduleEntrypointsRestArtifactProducer } from "@corporate-code-generator/adapter-java";
import { JavaSpringCleanMultimoduleInfraDatabaseArtifactProducer } from "@corporate-code-generator/adapter-java";
import { NunjucksTemplateEngine } from "@corporate-code-generator/template-engine-nunjucks";

const rootDirectory = resolve(dirname(fileURLToPath(import.meta.url)), "..", "..");

describe("Java multi-module generation", () => {
  it("renders the fourteen complete Maven reactor artifacts", async () => {
    const modelPath = resolve(rootDirectory, "examples", "wallet-service", "model.yaml");
    const document = await new ModelLoader().load(modelPath);
    const schemaVersion = new SchemaVersionDetector().detect(document);
    if (schemaVersion === undefined) throw new Error("Expected schema version.");
    new SchemaValidator(await new ModelSchemaRegistry().get(schemaVersion)).validate(document);
    const application = new ModelParser().parse(document);
    new SemanticValidator().validate(application);
    const profile = await new ProfileResolver(resolve(rootDirectory, "profiles")).resolve("java-spring-clean-multimodule");
    const modules = new ModuleResolver().resolveAll(profile.modules);
    const resolvedPack = await new TemplatePackResolver(resolve(rootDirectory, "template-packs")).resolve(profile.templatePack);
    const buildPlan = await new GenerationPlanner(
      new NunjucksTemplateEngine([resolvedPack.directory]),
      new JavaSpringCleanMultimoduleBuildArtifactProducer(),
      resolvedPack.templatePack,
    ).plan({ application, profile, modules });
    const corePlan = await new GenerationPlanner(
      new NunjucksTemplateEngine([resolvedPack.directory]),
      new JavaSpringCleanMultimoduleCoreArtifactProducer(),
      resolvedPack.templatePack,
    ).plan({ application, profile, modules });
    const restPlan = await new GenerationPlanner(
      new NunjucksTemplateEngine([resolvedPack.directory]),
      new JavaSpringCleanMultimoduleEntrypointsRestArtifactProducer(),
      resolvedPack.templatePack,
    ).plan({ application, profile, modules });
    const infraDatabasePlan = await new GenerationPlanner(
      new NunjucksTemplateEngine([resolvedPack.directory]),
      new JavaSpringCleanMultimoduleInfraDatabaseArtifactProducer(),
      resolvedPack.templatePack,
    ).plan({ application, profile, modules });
    const configurationPlan = await new GenerationPlanner(
      new NunjucksTemplateEngine([resolvedPack.directory]),
      new JavaSpringCleanMultimoduleConfigurationArtifactProducer(),
      resolvedPack.templatePack,
    ).plan({ application, profile, modules });
    const operations = [
      ...buildPlan.operations,
      ...corePlan.operations,
      ...restPlan.operations,
      ...infraDatabasePlan.operations,
      ...configurationPlan.operations,
    ];

    expect(operations.map((operation) => operation.targetPath)).toEqual([
      "pom.xml", "core/pom.xml", "entrypoints/rest/pom.xml", "infra/database/pom.xml", "configuration/pom.xml",
      "core/src/main/java/io/github/jtsato/walletservice/core/domains/wallet/model/Wallet.java",
      "core/src/main/java/io/github/jtsato/walletservice/core/domains/wallet/gateway/WalletGateway.java",
      "core/src/main/java/io/github/jtsato/walletservice/core/domains/wallet/usecase/find/FindWalletsUseCase.java",
      "core/src/main/java/io/github/jtsato/walletservice/core/domains/wallet/usecase/find/FindWalletsUseCaseInteractor.java",
      "entrypoints/rest/src/main/java/io/github/jtsato/walletservice/entrypoint/rest/domains/wallet/WalletController.java",
      "entrypoints/rest/src/main/java/io/github/jtsato/walletservice/entrypoint/rest/domains/wallet/WalletResponse.java",
      "infra/database/src/main/java/io/github/jtsato/walletservice/infra/domains/wallet/WalletGatewayProvider.java",
      "configuration/src/main/java/io/github/jtsato/walletservice/WalletServiceApplication.java",
      "configuration/src/main/java/io/github/jtsato/walletservice/configuration/domains/wallet/WalletConfiguration.java",
    ]);
    for (const operation of operations) {
      const goldenModule = goldenModuleFor(operation.targetPath);
      const golden = await readFile(resolve(
        rootDirectory,
        "tests",
        "golden",
        "java-spring-clean-multimodule",
        goldenModule,
        operation.targetPath,
      ), "utf8");
      expect(normalize(operation.content)).toBe(normalize(golden));
    }
  });
});

function normalize(value: string): string {
  return value.replaceAll("\r\n", "\n");
}

function goldenModuleFor(targetPath: string): string {
  if (targetPath.startsWith("core/src/")) return "core";
  if (targetPath.startsWith("entrypoints/rest/src/")) return "entrypoints-rest";
  if (targetPath.startsWith("infra/database/src/")) return "infra-database";
  if (targetPath.startsWith("configuration/src/")) return "configuration";
  return "build";
}
